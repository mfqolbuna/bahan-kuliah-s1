﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMI_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Berat Badan tidak boleh kosong.");
                return;
            }
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("TInggi Badan tidak boleh kosong.");
                return;
            }

            double berat = Convert.ToDouble(textBox1.Text);
            double tinggi = Convert.ToDouble(textBox2.Text);

            double bmi = berat / (tinggi * tinggi);

            string kategori;
            if (bmi < 18.5)
            {
                kategori = "Kurus";
            }

            else if (bmi >= 18.5 && bmi < 25)
            {
                kategori = "Normal";
            }
            else
            {
                kategori = "Gemuk";
            }
            label5.Text = "Kategori: " + kategori;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
