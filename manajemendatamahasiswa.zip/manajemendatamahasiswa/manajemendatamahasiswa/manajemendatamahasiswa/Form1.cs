﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static AppMahasiswa.Form1;

namespace AppMahasiswa
{
    public partial class Form1 : Form
    {
        private List<Mahasiswa> mahasiswaList = new List<Mahasiswa>();

        public Form1()
        {
            InitializeComponent();
        }
        public class Mahasiswa
        {
            public string Nama { get; set; }
            public int Angkatan { get; set; }
            public string Jurusan { get; set; }
            public string Status { get; set; }

            public Mahasiswa(String nama, int angkatan, string jurusan, string status)
            {
                Nama = nama;
                Angkatan = angkatan;
                Jurusan = jurusan;
                Status = status;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnMhs_Click(object sender, EventArgs e)
        {
            TambahkanMahasiswa(txtNama.Text, int.Parse(txtAngkatan.Text), txtJurusan.Text, "Reguler");
        }

        private void btnMhsRPL_Click(object sender, EventArgs e)
        {
            TambahkanMahasiswa(txtNama.Text, int.Parse(txtAngkatan.Text), txtJurusan.Text, "RPL");
        }

        private void TambahkanMahasiswa(string nama, int angkatan, string jurusan, string status)
        {
            Mahasiswa mahasiswa = new Mahasiswa(nama, angkatan, jurusan, status);
            mahasiswaList.Add(mahasiswa);
            TampilkanMahasiswa();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            listMhs.Items.Clear();
            listAngkatan.Items.Clear();
            listJurusan.Items.Clear();
            listStatus.Items.Clear();

            foreach (var mahasiswa in mahasiswaList.Where(m => m.Status == "RPL"))
            {
                listMhs.Items.Add(mahasiswa.Nama);
                listAngkatan.Items.Add(mahasiswa.Angkatan.ToString());
                listJurusan.Items.Add(mahasiswa.Jurusan);
                listStatus.Items.Add(mahasiswa.Status);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            listMhs.Items.Clear();
            listAngkatan.Items.Clear();
            listJurusan.Items.Clear();
            listStatus.Items.Clear();

            foreach (var mahasiswa in mahasiswaList.Where(m => m.Status == "Reguler"))
            {
                listMhs.Items.Add(mahasiswa.Nama);
                listAngkatan.Items.Add(mahasiswa.Angkatan.ToString());
                listJurusan.Items.Add(mahasiswa.Jurusan);
                listStatus.Items.Add(mahasiswa.Status);
            }

        }

        private void TampilkanMahasiswa()
        {
            listMhs.Items.Clear();
            listAngkatan.Items.Clear();
            listJurusan.Items.Clear();
            listStatus.Items.Clear();

            foreach (var mahasiswa in mahasiswaList)
            {
                listMhs.Items.Add(mahasiswa.Nama);
                listAngkatan.Items.Add(mahasiswa.Angkatan.ToString());
                listJurusan.Items.Add(mahasiswa.Jurusan);
                listStatus.Items.Add(mahasiswa.Status);
            }
        }


        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (mahasiswaList.Count > 0)
            {
                mahasiswaList.RemoveAt(mahasiswaList.Count - 1);
                TampilkanMahasiswa();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            mahasiswaList.Clear();

            listMhs.Items.Clear();
            listAngkatan.Items.Clear();
            listJurusan.Items.Clear();
            listStatus.Items.Clear();
        }
    }
}
