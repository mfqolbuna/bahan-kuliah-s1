﻿namespace AppMahasiswa
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listMhs = new System.Windows.Forms.ListBox();
            this.listAngkatan = new System.Windows.Forms.ListBox();
            this.listJurusan = new System.Windows.Forms.ListBox();
            this.listStatus = new System.Windows.Forms.ListBox();
            this.txtNama = new System.Windows.Forms.TextBox();
            this.txtAngkatan = new System.Windows.Forms.TextBox();
            this.txtJurusan = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnMhs = new System.Windows.Forms.Button();
            this.btnMhsRPL = new System.Windows.Forms.Button();
            this.btnHapus = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listMhs
            // 
            this.listMhs.FormattingEnabled = true;
            this.listMhs.Location = new System.Drawing.Point(8, 8);
            this.listMhs.Margin = new System.Windows.Forms.Padding(2);
            this.listMhs.Name = "listMhs";
            this.listMhs.Size = new System.Drawing.Size(151, 277);
            this.listMhs.TabIndex = 0;
            // 
            // listAngkatan
            // 
            this.listAngkatan.FormattingEnabled = true;
            this.listAngkatan.Location = new System.Drawing.Point(162, 8);
            this.listAngkatan.Margin = new System.Windows.Forms.Padding(2);
            this.listAngkatan.Name = "listAngkatan";
            this.listAngkatan.Size = new System.Drawing.Size(73, 277);
            this.listAngkatan.TabIndex = 1;
            // 
            // listJurusan
            // 
            this.listJurusan.FormattingEnabled = true;
            this.listJurusan.Location = new System.Drawing.Point(238, 8);
            this.listJurusan.Margin = new System.Windows.Forms.Padding(2);
            this.listJurusan.Name = "listJurusan";
            this.listJurusan.Size = new System.Drawing.Size(129, 277);
            this.listJurusan.TabIndex = 2;
            // 
            // listStatus
            // 
            this.listStatus.FormattingEnabled = true;
            this.listStatus.Location = new System.Drawing.Point(370, 8);
            this.listStatus.Margin = new System.Windows.Forms.Padding(2);
            this.listStatus.Name = "listStatus";
            this.listStatus.Size = new System.Drawing.Size(129, 277);
            this.listStatus.TabIndex = 3;
            // 
            // txtNama
            // 
            this.txtNama.Location = new System.Drawing.Point(590, 8);
            this.txtNama.Margin = new System.Windows.Forms.Padding(2);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(145, 20);
            this.txtNama.TabIndex = 4;
            // 
            // txtAngkatan
            // 
            this.txtAngkatan.Location = new System.Drawing.Point(590, 29);
            this.txtAngkatan.Margin = new System.Windows.Forms.Padding(2);
            this.txtAngkatan.Name = "txtAngkatan";
            this.txtAngkatan.Size = new System.Drawing.Size(145, 20);
            this.txtAngkatan.TabIndex = 5;
            // 
            // txtJurusan
            // 
            this.txtJurusan.Location = new System.Drawing.Point(590, 49);
            this.txtJurusan.Margin = new System.Windows.Forms.Padding(2);
            this.txtJurusan.Name = "txtJurusan";
            this.txtJurusan.Size = new System.Drawing.Size(145, 20);
            this.txtJurusan.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(515, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Nama";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(515, 31);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Angkatan";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(515, 51);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Jurusan";
            // 
            // btnMhs
            // 
            this.btnMhs.Location = new System.Drawing.Point(517, 87);
            this.btnMhs.Margin = new System.Windows.Forms.Padding(2);
            this.btnMhs.Name = "btnMhs";
            this.btnMhs.Size = new System.Drawing.Size(167, 25);
            this.btnMhs.TabIndex = 12;
            this.btnMhs.Text = "Tambah Mahasiswa Reguler";
            this.btnMhs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMhs.UseVisualStyleBackColor = true;
            this.btnMhs.Click += new System.EventHandler(this.btnMhs_Click);
            // 
            // btnMhsRPL
            // 
            this.btnMhsRPL.Location = new System.Drawing.Point(517, 116);
            this.btnMhsRPL.Margin = new System.Windows.Forms.Padding(2);
            this.btnMhsRPL.Name = "btnMhsRPL";
            this.btnMhsRPL.Size = new System.Drawing.Size(167, 25);
            this.btnMhsRPL.TabIndex = 13;
            this.btnMhsRPL.Text = "Tambah Mahasiswa RPL";
            this.btnMhsRPL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMhsRPL.UseVisualStyleBackColor = true;
            this.btnMhsRPL.Click += new System.EventHandler(this.btnMhsRPL_Click);
            // 
            // btnHapus
            // 
            this.btnHapus.Location = new System.Drawing.Point(518, 203);
            this.btnHapus.Margin = new System.Windows.Forms.Padding(2);
            this.btnHapus.Name = "btnHapus";
            this.btnHapus.Size = new System.Drawing.Size(166, 25);
            this.btnHapus.TabIndex = 14;
            this.btnHapus.Text = "Hapus Data Terakhir";
            this.btnHapus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHapus.UseVisualStyleBackColor = true;
            this.btnHapus.Click += new System.EventHandler(this.btnHapus_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(517, 145);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(167, 25);
            this.button1.TabIndex = 15;
            this.button1.Text = "Tampilkan Mahasiswa RPL";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(518, 174);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(166, 25);
            this.button2.TabIndex = 16;
            this.button2.Text = "Tampilkan Mahasiswa Reguler";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(518, 232);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(166, 25);
            this.button3.TabIndex = 17;
            this.button3.Text = "Hapus Semua";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 292);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnHapus);
            this.Controls.Add(this.btnMhsRPL);
            this.Controls.Add(this.btnMhs);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtJurusan);
            this.Controls.Add(this.txtAngkatan);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.listStatus);
            this.Controls.Add(this.listJurusan);
            this.Controls.Add(this.listAngkatan);
            this.Controls.Add(this.listMhs);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listMhs;
        private System.Windows.Forms.ListBox listAngkatan;
        private System.Windows.Forms.ListBox listJurusan;
        private System.Windows.Forms.ListBox listStatus;
        private System.Windows.Forms.TextBox txtNama;
        private System.Windows.Forms.TextBox txtAngkatan;
        private System.Windows.Forms.TextBox txtJurusan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnMhs;
        private System.Windows.Forms.Button btnMhsRPL;
        private System.Windows.Forms.Button btnHapus;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}

