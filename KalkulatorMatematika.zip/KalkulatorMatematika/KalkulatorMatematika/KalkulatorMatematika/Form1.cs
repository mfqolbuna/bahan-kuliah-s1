﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class Form1 : Form
    {
        private const string V = "Cos(";
        private string derajat;

        public object Hasilcalc { get; private set; }

        public Form1() => InitializeComponent();

        private void button1_Click(object sender, EventArgs e)
        {
            Double Hasilcalc = 0;
            Double angka1 = 0;

            angka1 = Convert.ToDouble(TxtAngka1.Text);

            Hasilcalc = Math.Sqrt(angka1);
            LabelHassil.Text = Hasilcalc.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Double Hasilcalc = 0;
            Double angka1 = 0;
            Double angka2 = 0;

            angka1 = Convert.ToDouble(TxtAngka1.Text);
            angka2 = Convert.ToDouble(TxtAngka2.Text);

            Hasilcalc = Math.Log(angka1, angka2);

            LabelHassil.Text = Hasilcalc.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Double angka1 = Convert.ToDouble(TxtAngka1.Text);

            Double Hasilcalc = angka1 * angka1;

            LabelHassil.Text = Hasilcalc.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Double Hasilcalc = 0;
            Double angka1 = 0;
            Double angka2 = 0;

            angka1 = Convert.ToDouble(TxtAngka1.Text);
            angka2 = Convert.ToDouble(TxtAngka2.Text);

            Hasilcalc = Math.Pow(angka1, angka2);

            LabelHassil.Text = Hasilcalc.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Double Hasilcalc = 0;
            Double angka1 = 0;

            angka1 = Convert.ToDouble(TxtAngka1.Text);
            Hasilcalc = Math.Abs(angka1);

            LabelHassil.Text = Hasilcalc.ToString();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Double Hasilcalc = 0;
            Double angka1 = 0;

            angka1 = Convert.ToDouble(TxtAngka1.Text);
            int n = Convert.ToInt32(TxtAngka1.Text);
            long hasil = Faktorial(n);
            LabelHassil.Text = +n + Hasilcalc.ToString();
        }
        private long Faktorial(int n) => n == 0 || n == 1 ? 1 : n * Faktorial(n - 1);

        private Label GetLabelHassil()
        {
            return LabelHassil;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(TxtAngka1.Text);
            int b = Convert.ToInt32(TxtAngka2.Text);

            int hasil = a % b;

            LabelHassil.Text = "Hasil " + a + " mod " + b + " adalah: " + Hasilcalc.ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Double Hasilcalc = 0;
            Double angka1 = 0;
            Double radian = 0;

            angka1 = Convert.ToDouble(TxtAngka1.Text);
            radian = derajat * Math.PI / 100;
            Hasilcalc = Math.Sin(radian);

            LabelHassil.Text = "Sin(" + derajat + ") = " + Hasilcalc.ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Double Hasilcalc = 0;
            Double angka1 = 0;
            Double radian = 0;

            angka1 = Convert.ToDouble(TxtAngka1.Text);
            radian = derajat * Math.PI / 100;
            Hasilcalc = Math.Cos(radian);

            LabelHassil.Text = "Cos(" + derajat + ") = " + Hasilcalc.ToString();

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Double Hasilcalc = 0;
            Double angka1 = 0;
            Double radian = 0;

            angka1 = Convert.ToDouble(TxtAngka1.Text);
            radian = derajat * Math.PI / 100;
            Hasilcalc = Math.Tan(radian);

            LabelHassil.Text = "Tan(" + derajat + ") = " + Hasilcalc.ToString();


        }
    }
}
}