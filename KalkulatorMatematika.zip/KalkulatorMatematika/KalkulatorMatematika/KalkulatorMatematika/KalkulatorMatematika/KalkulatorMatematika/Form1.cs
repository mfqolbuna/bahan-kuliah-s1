﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class Form1 : Form
    {
        private const string V = "Cos(";
        private string derajat;

        public object Hasilcalc { get; private set; }

        public Form1() => InitializeComponent();

        private void button1_Click_1(object sender, EventArgs e)
        {
            Double a = 0;
            Double c = 0;
            a = Convert.ToDouble(textBox1.Text);
            c = a * a;
            label5.Text = c.ToString();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Double a = 0;
            Double c = 0;
            a = Convert.ToDouble(textBox1.Text);
            c = Math.Sqrt(a);
            label5.Text = c.ToString();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Double a = 0;
            Double b = 0;
            Double c = 0;
            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox2.Text);
            c = Math.Log(a, b);
            label5.Text = c.ToString();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Double a = 0;
            Double b = 0;
            Double c = 0;
            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox2.Text);
            c = Math.Pow(a, b);
            label5.Text = c.ToString();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Double a = 0;
            Double c = 0;
            a = Convert.ToDouble(textBox1.Text);
            c = Math.Abs(a);
            label5.Text = c.ToString();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(textBox1.Text);
            int n = Convert.ToInt32(textBox1.Text);
            long c = Faktorial(n);
            label5.Text = +n + c.ToString();
        }
        private long Faktorial(int n) => n == 0 || n == 1 ? 1 : n * Faktorial(n - 1);

        private void button7_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBox1.Text);
            int b = Convert.ToInt32(textBox2.Text);
            int c = a % b;
            label5.Text = "Hasil " + a + " mod " + b + " adalah: " + c.ToString();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(textBox1.Text);
            double c = Math.Sin(a * (Math.PI / 180));
            label5.Text = c.ToString();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(textBox1.Text);
            double c = Math.Cos(a * (Math.PI / 180));
            label5.Text = c.ToString();
        }
        private void button10_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(textBox1.Text);
            double c = Math.Tan(a * (Math.PI / 180));
            label5.Text = c.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
