﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Validasi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            btnSubmit.Enabled = false;
        }
        private void CheckValidation()
        {
            bool isNamaValid = !string.IsNullOrWhiteSpace(txtNama_TextChanged.Text);
            bool isUsiaValid = int.TryParse(txtUsia_TextChanged.Text, out _);
            bool isJenisKelaminSelected = rbLaki_CheckedChanged.Checked || rbPerempuan_CheckedChanged.Checked;
            bool isSyaratChecked = cbSyarat_CheckedChanged.Checked;

            // Aktifkan tombol submit jika semua kondisi terpenuhi
            btnSubmit.Enabled = isNamaValid && isUsiaValid && isJenisKelaminSelected && isSyaratChecked;
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNama_TextChanged(object sender, EventArgs e)
        {
            CheckValidation();
        }

        private void txtUsia_TextChanged(object sender, EventArgs e)
        {
            CheckValidation();
        }

        private void rbLaki_CheckedChanged(object sender, EventArgs e)
        {
            CheckValidation();
        }

        private void rbPerempuan_CheckedChanged(object sender, EventArgs e)
        {
            CheckValidation();
        }

        private void cbSyarat_CheckedChanged(object sender, EventArgs e)
        {
            CheckValidation();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNama_TextChanged.Text))
            {
                MessageBox.Show("Nama tidak boleh kosong.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(txtUsia_TextChanged.Text, out _))
            {
                MessageBox.Show("Usia harus berupa angka.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validasi jika tidak ada jenis kelamin yang dipilih
            if (!rbLaki_CheckedChanged.Checked && !rbPerempuan_CheckedChanged.Checked)
            {
                MessageBox.Show("Jenis kelamin harus dipilih.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validasi jika checkbox syarat tidak dicentang
            if (!cbSyarat_CheckedChanged.Checked)
            {
                MessageBox.Show("Anda harus menyetujui syarat dan ketentuan.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Jika semua validasi terpenuhi
            MessageBox.Show("Input Berhasil!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
    }
}
